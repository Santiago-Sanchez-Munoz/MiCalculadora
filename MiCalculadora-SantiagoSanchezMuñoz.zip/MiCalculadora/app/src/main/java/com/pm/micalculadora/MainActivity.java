package com.pm.micalculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

/*Codigo realizado por Santiago Sanchez Munoz
Codigo 1005832006
Curso Computacion movil
 */

public class MainActivity extends AppCompatActivity {
    //Realizar un enlace co el resultado o el textView

    TextView tvResultado;
    //Valaores con los que se realizaran las operaciones
    float number1=0.0f;
    float number2=0.0f;
    float value= 0.0f;
    String operator="";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Clase llamada R que conteine propiedades del aplicativo, nos interesa el ID
        tvResultado = findViewById(R.id.tvResultado);
      //  tvResultado.setText(); //Modificacion del resultado


    }

    public void EscribirCero(View view) {
        //Conversion del texto a cadena y posteriormente a float para operar
        value = Float.parseFloat(tvResultado.getText().toString());
        if(value==0.0f){
            tvResultado.setText("0");
        }else{
            tvResultado.setText(tvResultado.getText()+"0");
        }
    }

    public void EscribirPunto(View view) {
        value=Float.parseFloat(tvResultado.getText().toString());
        if(tvResultado.getText().toString().contains(".")){
           //Mostrar que no se puede colocar mas puntos
            Toast.makeText(this, "Ya existe punto decimal",Toast.LENGTH_LONG).show();
        }else{
            tvResultado.setText(tvResultado.getText()+".");
            //En este paso, se anade el punto al numero
        }

    }

    public void EscribirUno(View view) {
    //Conversion del texto a cadena y posteriormente a float para operar
        value= Float.parseFloat(tvResultado.getText().toString());
        if(value==0.0f){
            tvResultado.setText("1");
        }else {
            tvResultado.setText(tvResultado.getText() + "1");
        }
    }


    public void EscribirDos(View view) {
        //Conversion del texto a cadena y posteriormente a float para operar
        value= Float.parseFloat(tvResultado.getText().toString());
        if(value==0.0f){
            tvResultado.setText("2");
        }else {
            tvResultado.setText(tvResultado.getText() + "2");
        }
    }

    public void EscribirTres(View view) {
        //Conversion del texto a cadena y posteriormente a float para operar
        value= Float.parseFloat(tvResultado.getText().toString());
        if(value==0.0f){
            tvResultado.setText("3");
        }else {
            tvResultado.setText(tvResultado.getText() + "3");
        }
    }

    public void EscribirCuatro(View view) {
        //Conversion del texto a cadena y posteriormente a float para operar
        value= Float.parseFloat(tvResultado.getText().toString());
        if(value==0.0f){
            tvResultado.setText("4");
        }else {
            tvResultado.setText(tvResultado.getText() + "4");
        }
    }

    public void EscribirCinco(View view) {
        //Conversion del texto a cadena y posteriormente a float para operar
        value= Float.parseFloat(tvResultado.getText().toString());
        if(value==0.0f){
            tvResultado.setText("5");
        }else {
            tvResultado.setText(tvResultado.getText() + "5");
        }
    }

    public void EscribirSeis(View view) {
        //Conversion del texto a cadena y posteriormente a float para operar
        value= Float.parseFloat(tvResultado.getText().toString());
        if(value==0.0f){
            tvResultado.setText("6");
        }else {
            tvResultado.setText(tvResultado.getText() + "6");
        }
    }

    public void EscribirSiete(View view) {
        //Conversion del texto a cadena y posteriormente a float para operar
        value= Float.parseFloat(tvResultado.getText().toString());
        if(value==0.0f){
            tvResultado.setText("7");
        }else {
            tvResultado.setText(tvResultado.getText() + "7");
        }
    }

    public void EscribirOcho(View view) {
        //Conversion del texto a cadena y posteriormente a float para operar
        value= Float.parseFloat(tvResultado.getText().toString());
        if(value==0.0f){
            tvResultado.setText("8");
        }else {
            tvResultado.setText(tvResultado.getText() + "8");
        }
    }

    public void EscribirNueve(View view) {
        //Conversion del texto a cadena y posteriormente a float para operar
        value= Float.parseFloat(tvResultado.getText().toString());
        if(value==0.0f){
            tvResultado.setText("9");
        }else {
            tvResultado.setText(tvResultado.getText() + "9");
        }
    }

    public void Limpiar(View view) {
        tvResultado.setText("0");
        number1 =0.0f;
        number2 = 0.0f;
        operator = "";

    }

    public void CambiarSigno(View view) {
        //Al valor existente en el textView, se le cambia el signo que tiene multiplicando por -1
        value = -1*Float.parseFloat(tvResultado.getText().toString());
        //Se muestran los cambios nuevamente en el textView
        tvResultado.setText(value+"");
    }


    public void Porcentaje(View view) {
        value = Float.parseFloat(tvResultado.getText().toString())/100; //El valor que se haya ingresado, se divide entre 100, denota el porcentaje que se toma
        tvResultado.setText(value+"");
    }


    public void Division(View view) {
        number1= Float.parseFloat(tvResultado.getText().toString());
        operator="/";
        tvResultado.setText("0");
    }

    public void Multiplicar(View view) {
        number1= Float.parseFloat(tvResultado.getText().toString());
        operator="x";
        tvResultado.setText("0");
    }

    public void Restar(View view) {
        number1= Float.parseFloat(tvResultado.getText().toString());
        operator="-";
        tvResultado.setText("0");
    }

    public void Sumar(View view) {
        number1= Float.parseFloat(tvResultado.getText().toString());
        operator="+";
        tvResultado.setText("0");
    }

    public void Resultado(View view) {
        number2 = Float.parseFloat(tvResultado.getText().toString());
        float result = 0.0f;
        if(operator.equals("/")){ // La logica que sigue para el proceso de division es la siguiente
            if(number2==0.0f){
                tvResultado.setText("0");
                Toast.makeText(this, "Operacion no valida",Toast.LENGTH_LONG).show();
            }else{
                 result = number1/number2;
                tvResultado.setText(result+"");
            }
        }else if(operator.equals("+")){// En caso de que sea una suma
            result = number1 + number2;
            tvResultado.setText(result+"");
        }else if(operator.equals("-")){//En caso de que sea una resta
            result = number1-number2;
            tvResultado.setText(result+"");
        }else if (operator.equals("x")){//En caso de que sea una multiplicacion
            result = number1*number2;
            tvResultado.setText(result+"");
        }
        number2 =0.0f;
        number1= 0.0f;
        operator="";

    }
}